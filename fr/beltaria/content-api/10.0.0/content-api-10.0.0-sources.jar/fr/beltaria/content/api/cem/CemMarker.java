package fr.beltaria.content.api.cem;

/**
 * The marker that tells the OptiFine client which CEM model to draw on a mob: vanilla metadata
 * only, written by the server alone. The server-side encoders and the expressions the generated
 * {@code .jem} reads live here together, so the two sides cannot drift apart.
 *
 * <p><strong>The variant</strong> lives in the fraction of the max health: {@code max = base +
 * (k + 0.5) / 64}, with any integer base. The CEM expression reads it back with
 * {@code between(frac(max_health) * 64, k + 0.25, k + 0.75)}, a quarter of a cell of margin on
 * each side. The client receives the max health as a double and reads it as a float: at 2048 (the
 * spigot.yml cap) a float step is 2^-12, well under the quarter cell (2^-8). It comes with the
 * sneak flag (no vanilla mob sets it, proven in phase 1): only both together open the variant, so
 * a vanilla mob whose max health happens to be fractional (a zombie leader) stays vanilla.
 *
 * <p><strong>The arm clip</strong> (attack, id 0, or special, 1 to 15) lives in the fraction of
 * the current health, in 4096 cells: {@code health = integer + (cell + 0.5) / 4096}, exact in
 * float up to the 2048 cap. An odd cell is a clip playing: {@code cell = 2 × (id × 64 + start) +
 * 1}, where {@code start} is the world age (total ticks, never changed by /time or a player time)
 * at the clip's first tick, modulo 64. An even cell is the rest: no arm clip; the rest just under
 * a playing cell costs 1/4096 of a point. The client reads the parity with
 * {@code fmod(floor(frac(health) * 4096), 2)}, the id with {@code floor(frac(health) * 32)} and the
 * elapsed ticks with
 * {@code fmod(time - fmod(floor(frac(health) * 2048), 64), 64)}: OptiFine's {@code time} is the
 * client's world age modulo 24000 plus the partial ticks, and 24000 is a multiple of 64. The client
 * age follows the server's (S03 every second; measured 2026-10-30, constant offset, ±0.06 tick,
 * unchanged by /time set, setPlayerTime or doDaylightCycle, also under Lunar with Time Changer),
 * and the health and S03 cross the same connection, so the clip starts on the client when the
 * health arrives. The clip plays while the elapsed time is under its length: the server must set
 * the rest before 64 ticks, or the clip plays again; arm clips are at most
 * {@link #maxArmClipSeconds()} long, which leaves 16 ticks of margin.
 *
 * <p>The encoded health never exceeds the real one (encoding never heals): the integer part drops
 * by one when the cell's fraction would exceed the health's, and the boss loses at most one point
 * and 1/4096 per clip (start then rest; on average half a point). Any other change of the health that leaves its
 * fraction elsewhere (a damage that is not a whole number) reads as another cell: the server keeps
 * the fraction, or encodes again before the change is sent.
 *
 * <p>Pure functions. Sizes are methods, not {@code static final} constants: javac would copy a
 * constant into a plugin compiled against this API, which would keep the old value after
 * BeltariaContent changes it.
 */
public final class CemMarker {

    private static final int VARIANTS = 64;
    private static final int CLIPS = 16;
    private static final int CELLS = 4096;
    private static final int PERIOD = 64;
    private static final double MAX_ARM_CLIP = 2.4;
    private static final double MAX_HEALTH_CAP = 2048.0;
    private static final double STRIDE = 2 * Math.PI / 0.6662;

    private CemMarker() {
    }

    /** @return variants per host type */
    public static int variants() {
        return VARIANTS;
    }

    /** @return one-shot clips per model: the attack (0) and fifteen special clips */
    public static int clips() {
        return CLIPS;
    }

    /** @return the clock period of an arm clip, in ticks: the start is the world age modulo it */
    public static int clipPeriod() {
        return PERIOD;
    }

    /**
     * @return the longest arm clip, in seconds: the server sets the rest after the clip, and has
     *         {@link #clipPeriod()} ticks minus this before the clip would play again
     */
    public static double maxArmClipSeconds() {
        return MAX_ARM_CLIP;
    }

    /** @return the server-side max health cap (spigot.yml, attribute.maxHealth.max) */
    public static double maxHealthCap() {
        return MAX_HEALTH_CAP;
    }

    /**
     * @return the {@code limb_swing} of one loop of the walk clip: the client's leg period
     *         ({@code cos(limb_swing * 0.6662)}), which the generated walk clips and the server's
     *         stride clock both follow
     */
    public static double stride() {
        return STRIDE;
    }

    /**
     * @param base wanted integer max health, from 1 to {@link #maxHealthCap()} - 1
     * @param variant k, from 0 to {@link #variants()} - 1
     * @return the max health that carries the variant
     */
    public static double maxHealth(int base, int variant) {
        if (base < 1 || base >= MAX_HEALTH_CAP) {
            throw new IllegalArgumentException("vie maximale " + base + " hors de [1, "
                    + (int) (MAX_HEALTH_CAP - 1) + "]");
        }
        checkVariant(variant);
        return base + (variant + 0.5) / VARIANTS;
    }

    /**
     * What the client reads, to the float.
     *
     * @return the variant carried by this max health, or -1 if its fraction falls outside the
     *         cells (a vanilla mob)
     */
    public static int variantOf(double maxHealth) {
        float seen = (float) maxHealth;
        double scaled = (seen - Math.floor(seen)) * VARIANTS;
        int cell = (int) Math.floor(scaled);
        double inCell = scaled - cell;
        return inCell >= 0.25 && inCell <= 0.75 ? cell : -1;
    }

    /**
     * The health that starts an arm clip now.
     *
     * @param health current health
     * @param maxHealth max health (carries the variant)
     * @param clip id of the clip, from 0 (attack) to {@link #clips()} - 1
     * @param worldAge the world's age (total ticks) at the clip's first tick
     * @return the health that carries the clip, at most {@code maxHealth}; 0 stays 0 (dead
     *         stays dead)
     */
    public static double healthWithClip(double health, double maxHealth, int clip, long worldAge) {
        if (clip < 0 || clip >= CLIPS) {
            throw new IllegalArgumentException("clip " + clip + " hors de [0, " + (CLIPS - 1) + "]");
        }
        return encode(health, maxHealth, 2 * (clip * PERIOD + (int) Math.floorMod(worldAge, PERIOD))
                + 1);
    }

    /**
     * The health that ends the arm clip: the rest. A health that already reads as the rest is kept
     * as is.
     *
     * @return the health at rest, at most {@code maxHealth}; 0 stays 0
     */
    public static double healthAtRest(double health, double maxHealth) {
        double kept = Math.min(health, maxHealth);
        if (!(health > 0.0) || cellOf(kept) % 2 == 0) {
            return health > 0.0 ? kept : 0.0;
        }
        // The rest cell just under: 1/4096 of a point.
        return encode(health, maxHealth, cellOf(kept) - 1);
    }

    private static double encode(double health, double maxHealth, int cell) {
        if (!(health > 0.0)) {
            return 0.0;
        }
        double fraction = (cell + 0.5) / CELLS;
        double kept = Math.min(health, maxHealth);
        double encoded = Math.floor(kept) + fraction;
        // Never above the real health: encoding a clip must not heal.
        if (encoded > kept) {
            encoded -= 1.0;
        }
        // A monster under one health point cannot carry this cell without dying: it keeps its
        // health, and the client reads whatever cell its fraction names.
        return encoded > 0.0 ? encoded : health;
    }

    private static int cellOf(double health) {
        float seen = (float) health;
        return (int) Math.floor((seen - Math.floor(seen)) * CELLS);
    }

    /**
     * @return the arm clip id the client reads in this health, from 0 to {@link #clips()} - 1,
     *         or -1 at rest
     */
    public static int clipOf(double health) {
        int cell = cellOf(health);
        return cell % 2 == 1 ? cell / 2 / PERIOD : -1;
    }

    /** @return the clip's start (world age modulo {@link #clipPeriod()}), or -1 at rest */
    public static int startOf(double health) {
        int cell = cellOf(health);
        return cell % 2 == 1 ? cell / 2 % PERIOD : -1;
    }

    /** @return the CEM expression true on the mobs of this variant only */
    public static String gate(int variant) {
        checkVariant(variant);
        return "(is_sneaking && between(frac(max_health) * " + VARIANTS + ", " + (variant + 0.25)
                + ", " + (variant + 0.75) + "))";
    }

    /**
     * @return the CEM expression of the arm clip id, from 0 to {@link #clips()} - 1, meaningful
     *         only when {@link #playingExpression()} is true
     */
    public static String clipExpression() {
        return "floor(frac(health) * " + (CELLS / 2 / PERIOD) + ")";
    }

    /** @return the CEM expression true while the health carries a playing arm clip */
    public static String playingExpression() {
        return "equals(fmod(floor(frac(health) * " + CELLS + "), 2), 1, 0.25)";
    }

    /**
     * @return the CEM expression of the ticks since the arm clip's start, from 0 to
     *         {@link #clipPeriod()}, partial ticks included; meaningless at rest
     */
    public static String elapsedExpression() {
        return "fmod(time - fmod(floor(frac(health) * " + (CELLS / 2) + "), " + PERIOD + "), " + PERIOD
                + ")";
    }

    private static void checkVariant(int variant) {
        if (variant < 0 || variant >= VARIANTS) {
            throw new IllegalArgumentException("variante " + variant + " hors de [0, "
                    + (VARIANTS - 1) + "]");
        }
    }
}
