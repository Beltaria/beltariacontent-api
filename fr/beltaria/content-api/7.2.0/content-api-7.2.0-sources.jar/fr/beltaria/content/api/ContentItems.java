package fr.beltaria.content.api;

import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * BeltariaContent's items, for other plugins: build one by its id, read the id of a stack.
 *
 * <p>Registered by BeltariaContent in Bukkit's ServicesManager while it is enabled; {@link #get()}
 * finds it. A plugin that only softdepends on BeltariaContent must check that BeltariaContent is
 * enabled before touching this class: the interface ships in BeltariaContent's jar.
 *
 * <p>Main thread only. {@code /content reload} replaces the catalogue: never cache a built stack
 * as the definition of an item, ask again.
 */
public interface ContentItems {

    /** @return the implementation BeltariaContent registered, or null when it is not enabled */
    static ContentItems get() {
        RegisteredServiceProvider<ContentItems> provider =
                Bukkit.getServicesManager().getRegistration(ContentItems.class);
        return provider == null ? null : provider.getProvider();
    }

    /**
     * A new stack of that item, exactly what {@code /content give} makes: material, name, lore,
     * enchantments, flags and the {@code beltaria:id} marker.
     *
     * @param amount at least 1; capped at the material's max stack size
     * @return a fresh stack the caller owns, or null when no item has that id
     * @throws IllegalArgumentException if {@code amount < 1}
     */
    ItemStack build(String id, int amount);

    /**
     * @return whether an item with that id is declared, under its id or one of its
     *         {@code former-ids}
     */
    boolean exists(String id);

    /**
     * The {@code beltaria:id} marker of that stack, canonical: an item made before a rename still
     * carries its former id, and this answers with the id the catalogue declares today. A marker
     * the catalogue does not know comes back as is.
     *
     * @return the canonical marker of that stack, or null (none, air, null)
     */
    String idOf(ItemStack item);

    /**
     * The canonical form of an id read elsewhere than on a stack (a config, a stored value).
     *
     * @return the declared id for {@code id} itself or for a {@code former-ids} entry naming it;
     *         {@code id} unchanged when the catalogue knows neither; null for null
     * @since 7.2.0
     */
    String canonicalId(String id);

    /**
     * The stack as BeltariaContent renews an old one when its player joins or opens a placed
     * container: its {@code former-ids} marker replaced by today's id, and its name, if it is
     * exactly one of the item's {@code former-names}, replaced by today's name. Nothing else
     * changes (amount, lore, enchantments, other persistent data, a name the player chose). For a
     * plugin that compares a stack with a freshly built one: the stack it still holds (a vault,
     * an auction, a stack taken out after the join) compares as a renewed one would.
     *
     * @return a renewed copy the caller owns; null when the stack is already today's, is not one
     *         of BeltariaContent's items, or is null or air. {@code item} itself is never changed.
     * @since 7.2.0
     */
    ItemStack renewed(ItemStack item);

    /** @return the declared ids, sorted; a snapshot that does not follow later reloads */
    Set<String> ids();
}
