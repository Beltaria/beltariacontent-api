package fr.beltaria.content.api.cem;

/**
 * The marker that tells the OptiFine client which CEM model to draw on a mob: vanilla metadata
 * only, written by the server alone. The server-side encoders and the expressions the generated
 * {@code .jem} reads live here together, so the two sides cannot drift apart.
 *
 * <p><strong>The variant</strong> lives in the fraction of the max health: {@code max = base +
 * (k + 0.5) / 64}, with any integer base. The CEM expression reads it back with
 * {@code between(frac(max_health) * 64, k + 0.25, k + 0.75)}, a quarter of a cell of margin on
 * each side. The client receives the max health as a double and reads it as a float: at 2048 (the
 * spigot.yml cap) a float step is 2^-12, well under the quarter cell (2^-8). It comes with the
 * sneak flag (no vanilla mob sets it, proven in phase 1): only both together open the variant, so
 * a vanilla mob whose max health happens to be fractional (a zombie leader) stays vanilla.
 *
 * <p><strong>The special clip</strong> of a boss lives in the fraction of the current health:
 * {@code health = integer + (id + 0.5) / 16}, read by {@code floor(frac(health) * 16)}. Id 0 is
 * the ordinary attack. The encoded health never exceeds the real one (encoding never heals): the
 * integer part drops by one when the clip's fraction would exceed the health's, and the boss loses
 * less than one health point per clip set.
 *
 * <p>Pure functions. Sizes are methods, not {@code static final} constants: javac would copy a
 * constant into a plugin compiled against this API, which would keep the old value after
 * BeltariaContent changes it.
 */
public final class CemMarker {

    private static final int VARIANTS = 64;
    private static final int CLIPS = 16;
    private static final double MAX_HEALTH_CAP = 2048.0;
    private static final double STRIDE = 2 * Math.PI / 0.6662;

    private CemMarker() {
    }

    /** @return variants per host type */
    public static int variants() {
        return VARIANTS;
    }

    /** @return one-shot clips per model: the attack (0) and fifteen special clips */
    public static int clips() {
        return CLIPS;
    }

    /** @return the server-side max health cap (spigot.yml, attribute.maxHealth.max) */
    public static double maxHealthCap() {
        return MAX_HEALTH_CAP;
    }

    /**
     * @return the {@code limb_swing} of one loop of the walk clip: the client's leg period
     *         ({@code cos(limb_swing * 0.6662)}), which the generated walk clips and the server's
     *         stride clock both follow
     */
    public static double stride() {
        return STRIDE;
    }

    /**
     * @param base wanted integer max health, from 1 to {@link #maxHealthCap()} - 1
     * @param variant k, from 0 to {@link #variants()} - 1
     * @return the max health that carries the variant
     */
    public static double maxHealth(int base, int variant) {
        if (base < 1 || base >= MAX_HEALTH_CAP) {
            throw new IllegalArgumentException("vie maximale " + base + " hors de [1, "
                    + (int) (MAX_HEALTH_CAP - 1) + "]");
        }
        checkVariant(variant);
        return base + (variant + 0.5) / VARIANTS;
    }

    /**
     * What the client reads, to the float.
     *
     * @return the variant carried by this max health, or -1 if its fraction falls outside the
     *         cells (a vanilla mob)
     */
    public static int variantOf(double maxHealth) {
        float seen = (float) maxHealth;
        double scaled = (seen - Math.floor(seen)) * VARIANTS;
        int cell = (int) Math.floor(scaled);
        double inCell = scaled - cell;
        return inCell >= 0.25 && inCell <= 0.75 ? cell : -1;
    }

    /**
     * @param health current health, as after a hit
     * @param maxHealth max health (carries the variant)
     * @param clip id of the clip to play on the next arm swing, from 0 to {@link #clips()} - 1
     * @return the health that carries the clip, at most {@code maxHealth}; 0 stays 0 (dead
     *         stays dead)
     */
    public static double healthWithClip(double health, double maxHealth, int clip) {
        if (clip < 0 || clip >= CLIPS) {
            throw new IllegalArgumentException("clip " + clip + " hors de [0, " + (CLIPS - 1) + "]");
        }
        if (!(health > 0.0)) {
            return 0.0;
        }
        double fraction = (clip + 0.5) / CLIPS;
        double kept = Math.min(health, maxHealth);
        double encoded = Math.floor(kept) + fraction;
        // Never above the real health: encoding a clip must not heal.
        if (encoded > kept) {
            encoded -= 1.0;
        }
        // A monster under one health point cannot carry this clip without dying: it keeps its
        // health, and the client plays the clip its fraction already names (a death blow).
        return encoded > 0.0 ? encoded : health;
    }

    /** @return the clip id the client reads in this health, from 0 to {@link #clips()} - 1 */
    public static int clipOf(double health) {
        float seen = (float) health;
        return (int) Math.floor((seen - Math.floor(seen)) * CLIPS);
    }

    /** @return the CEM expression true on the mobs of this variant only */
    public static String gate(int variant) {
        checkVariant(variant);
        return "(is_sneaking && between(frac(max_health) * " + VARIANTS + ", " + (variant + 0.25)
                + ", " + (variant + 0.75) + "))";
    }

    /** @return the CEM expression of the id of the one-shot clip being played */
    public static String clipExpression() {
        return "floor(frac(health) * " + CLIPS + ")";
    }

    private static void checkVariant(int variant) {
        if (variant < 0 || variant >= VARIANTS) {
            throw new IllegalArgumentException("variante " + variant + " hors de [0, "
                    + (VARIANTS - 1) + "]");
        }
    }
}
