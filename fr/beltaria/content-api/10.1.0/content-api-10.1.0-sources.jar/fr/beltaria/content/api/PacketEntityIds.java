package fr.beltaria.content.api;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * The one allocator of entity ids for entities that exist only in packets (armor stands of wings,
 * boss labels...). Two counters in two plugins would hand the same id to two entities on the same
 * client; this class ships in BeltariaContent's jar, so every plugin compiled against the API
 * shares this one counter.
 *
 * <p>Ids go down from {@code Integer.MAX_VALUE - 1}, far from the server's own ids, which go up
 * from 0. Any thread: the counter is atomic.
 */
public final class PacketEntityIds {

    private static final AtomicInteger NEXT = new AtomicInteger(Integer.MAX_VALUE - 1);

    private PacketEntityIds() {
    }

    /** @return an entity id no other packet entity and no server entity holds */
    public static int next() {
        return NEXT.getAndDecrement();
    }
}
