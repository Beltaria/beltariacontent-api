package fr.beltaria.content.api.cem;

import java.util.Objects;

/**
 * A CEM model of the pack, as {@code pack/monsters/models.yml} declares it: the single source of
 * the host and the variant a plugin marks a mob with ({@link CemMarker}), and of the clips and
 * keyframes it may play.
 *
 * @param id the model's id in {@code models.yml}
 * @param folder its folder under {@code pack/monsters/} (the id unless {@code model:} says
 *        otherwise: one model drawn on two hosts)
 * @param host the vanilla mob it is drawn on
 * @param variant its cell on that host, {@code 0} to {@link CemMarker#variants()} - 1
 * @param keyframes its special clips and effect keyframes
 */
public record CemModel(String id, String folder, CemHost host, int variant,
        CemKeyframes keyframes) {

    /** @throws IllegalArgumentException for a variant out of range */
    public CemModel {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(folder, "folder");
        Objects.requireNonNull(host, "host");
        Objects.requireNonNull(keyframes, "keyframes");
        if (variant < 0 || variant >= CemMarker.variants()) {
            throw new IllegalArgumentException("variante " + variant + " hors de [0, "
                    + (CemMarker.variants() - 1) + "]");
        }
    }
}
