package fr.beltaria.content.api;

import java.util.Set;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * BeltariaContent's items, for other plugins: build one by its id, read the id of a stack.
 *
 * <p>Registered by BeltariaContent in Bukkit's ServicesManager while it is enabled; {@link #get()}
 * finds it. A plugin that only softdepends on BeltariaContent must check that BeltariaContent is
 * enabled before touching this class: the interface ships in BeltariaContent's jar.
 *
 * <p>Main thread only. {@code /content reload} replaces the catalogue: never cache a built stack
 * as the definition of an item, ask again.
 */
public interface ContentItems {

    /** @return the implementation BeltariaContent registered, or null when it is not enabled */
    static ContentItems get() {
        RegisteredServiceProvider<ContentItems> provider =
                Bukkit.getServicesManager().getRegistration(ContentItems.class);
        return provider == null ? null : provider.getProvider();
    }

    /**
     * A new stack of that item, exactly what {@code /content give} makes: material, name, lore,
     * enchantments, flags and the {@code beltaria:id} marker.
     *
     * @param amount at least 1; capped at the material's max stack size
     * @return a fresh stack the caller owns, or null when no item has that id
     * @throws IllegalArgumentException if {@code amount < 1}
     */
    ItemStack build(String id, int amount);

    /** @return whether an item with that id is declared */
    boolean exists(String id);

    /** @return the {@code beltaria:id} marker of that stack, or null (none, air, null) */
    String idOf(ItemStack item);

    /** @return the declared ids, sorted; a snapshot that does not follow later reloads */
    Set<String> ids();
}
