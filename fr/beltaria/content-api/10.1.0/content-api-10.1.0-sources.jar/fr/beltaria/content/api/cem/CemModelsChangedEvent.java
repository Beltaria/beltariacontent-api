package fr.beltaria.content.api.cem;

import java.util.Map;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Fired on the main thread once {@code /content reload} has replaced the model snapshot: a
 * plugin that resolved its monsters against the old one loads them again against
 * {@link #models()}.
 */
public final class CemModelsChangedEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Map<String, CemModel> models;

    public CemModelsChangedEvent(Map<String, CemModel> models) {
        this.models = models;
    }

    /** @return the new snapshot, the one {@link CemModels#models()} now returns */
    public Map<String, CemModel> models() {
        return this.models;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
