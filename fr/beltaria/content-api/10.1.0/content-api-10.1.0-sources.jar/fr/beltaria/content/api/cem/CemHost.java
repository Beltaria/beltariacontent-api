package fr.beltaria.content.api.cem;

import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.CaveSpider;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.Endermite;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Silverfish;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Spider;

/**
 * The vanilla mobs that can carry a CEM model, and nothing else.
 *
 * <p>A host is kept only if its 1.8.9 renderer never reassigns its model (the zombie and the
 * guardian do every frame) and no vanilla mob sets the sneak flag (the ocelot does): monstres
 * report §3 and §7, proven in the OptiFine M6_pre2 client bytecode. The wither is left out (its
 * aura draws the vanilla wither at half health).
 *
 * <p>The box is the one the client aims at, in blocks; the pack generator checks the model's
 * {@code hitbox} bone against it.
 */
public enum CemHost {
    SKELETON("skeleton", Skeleton.class, 0.6, 1.99),
    SPIDER("spider", Spider.class, 1.4, 0.9),
    CAVE_SPIDER("cave_spider", CaveSpider.class, 0.7, 0.5),
    SILVERFISH("silverfish", Silverfish.class, 0.4, 0.3),
    ENDERMITE("endermite", Endermite.class, 0.4, 0.3),
    IRON_GOLEM("iron_golem", IronGolem.class, 1.4, 2.9),
    ENDER_DRAGON("dragon", EnderDragon.class, 16.0, 8.0),
    /**
     * The NPCs: a real, non-marker armor stand (a marker has no box to click). Its head is the
     * vanilla one in the unmarked branch: the item worn on an invisible stand's head (crates,
     * blocks, wings, auras) is placed by the head part.
     */
    ARMOR_STAND("armor_stand", ArmorStand.class, 0.5, 1.975);

    private final String jem;
    private final Class<? extends LivingEntity> type;
    private final double width;
    private final double height;

    CemHost(String jem, Class<? extends LivingEntity> type, double width, double height) {
        this.jem = jem;
        this.type = type;
        this.width = width;
        this.height = height;
    }

    /** @return the CEM file name, without {@code .jem}: {@code optifine/cem/<jem>.jem} */
    public String jem() {
        return this.jem;
    }

    public Class<? extends LivingEntity> type() {
        return this.type;
    }

    public double width() {
        return this.width;
    }

    public double height() {
        return this.height;
    }
}
