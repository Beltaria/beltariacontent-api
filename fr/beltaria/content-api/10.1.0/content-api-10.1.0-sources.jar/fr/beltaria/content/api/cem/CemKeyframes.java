package fr.beltaria.content.api.cem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * The effect keyframes ({@code particle}, {@code sound}) of a monster model, sorted by the clip
 * that carries them and brought to the clock the client gives that clip: the server replays them
 * at the same instant as the pose. BeltariaContent reads them from the {@code .bbmodel}; other
 * plugins never read a model file.
 *
 * <ul>
 * <li>arm ({@code attack}, clip 0, and specials 1 to 15): real time since the clip's start, the
 *     world age the server encodes ({@link CemMarker#healthWithClip}); a keyframe at {@code t} s
 *     falls {@code t × 20} ticks after it;</li>
 * <li>{@code hurt}, {@code death}: real time since the hit or the death;</li>
 * <li>{@code idle}: real time, looped ({@code fmod(age / 20, length)});</li>
 * <li>walk: the stride, {@code limb_swing}; one loop of the clip = {@link CemMarker#stride()}.</li>
 * </ul>
 */
public final class CemKeyframes {

    private static final CemKeyframes NONE = new CemKeyframes(List.of(), 0f, List.of(),
            new float[0]);

    /** The clip that carries a keyframe. */
    public enum Clip {
        IDLE, WALK, SWING, HURT, DEATH
    }

    /**
     * An effect keyframe.
     *
     * @param swing the arm clip id (0 attack, 1-15 special), -1 outside the arm
     * @param time the instant in the clip, in seconds
     * @param phase the position on the clip's clock: seconds (arm, idle, hurt, death),
     *        {@code limb_swing} in the stride (walk)
     */
    public record Cue(Clip clip, int swing, String clipName, String channel, float time,
            String name, double phase) {
    }

    private final List<Cue> cues;
    private final float idleLength;
    private final List<String> specials;
    /** The arm clips' lengths in seconds, by id (0 attack, then the specials). */
    private final float[] armLengths;

    private CemKeyframes(List<Cue> cues, float idleLength, List<String> specials,
            float[] armLengths) {
        this.cues = cues;
        this.idleLength = idleLength;
        this.specials = specials;
        this.armLengths = armLengths;
    }

    /** @return a model without effect keyframes */
    public static CemKeyframes none() {
        return NONE;
    }

    /**
     * @param cues every effect keyframe, clip by clip, in file order
     * @param idleLength the idle clip's length in seconds, 0 without idle
     * @param specials the special clip names, without {@code special_}, in id order (id = index
     *        + 1)
     * @throws IllegalArgumentException for more than {@link CemMarker#clips()} - 1 specials
     */
    public static CemKeyframes of(List<Cue> cues, float idleLength, List<String> specials) {
        return of(cues, idleLength, specials, new float[0]);
    }

    /**
     * @param armLengths the arm clips' lengths in seconds, by id: {@code attack} then the
     *        specials in id order; empty when unknown, else one per arm clip, each finite and
     *        {@code >= 0} (0: the model has no such clip)
     * @throws IllegalArgumentException for more than {@link CemMarker#clips()} - 1 specials or
     *         lengths that do not match them
     */
    public static CemKeyframes of(List<Cue> cues, float idleLength, List<String> specials,
            float[] armLengths) {
        if (specials.size() > CemMarker.clips() - 1) {
            throw new IllegalArgumentException(specials.size() + " clips speciaux, "
                    + (CemMarker.clips() - 1) + " au plus");
        }
        if (armLengths.length != 0 && armLengths.length != specials.size() + 1) {
            throw new IllegalArgumentException(armLengths.length + " durees de clips du bras, "
                    + (specials.size() + 1) + " attendues (attack puis les speciaux)");
        }
        for (float length : armLengths) {
            if (!(length >= 0f) || Float.isInfinite(length)) {
                throw new IllegalArgumentException("duree de clip du bras " + length);
            }
        }
        return new CemKeyframes(Collections.unmodifiableList(new ArrayList<>(cues)), idleLength,
                Collections.unmodifiableList(new ArrayList<>(specials)), armLengths.clone());
    }

    /**
     * @return the id of the clip {@code special_<name>} (1 to 15, alphabetical order), or -1 if
     *         the model has none
     */
    public int specialId(String name) {
        int index = this.specials.indexOf(name);
        return index < 0 ? -1 : index + 1;
    }

    /** @return the special clip names, without {@code special_}, in the order of their ids */
    public List<String> specials() {
        return this.specials;
    }

    /** @return every effect keyframe, clip by clip, in file order */
    public List<Cue> cues() {
        return this.cues;
    }

    /** @return the names set on at least one keyframe, without the empty name */
    public Set<String> names() {
        Set<String> names = new TreeSet<>();
        for (Cue cue : this.cues) {
            if (!cue.name().isEmpty()) {
                names.add(cue.name());
            }
        }
        return names;
    }

    /**
     * @param clip an arm clip id: 0 {@code attack}, 1-15 a special ({@link #specialId})
     * @return that clip's length in ticks, rounded up ({@code ceil(seconds x 20)}, a float
     *         error of 1e-4 tick forgiven), 0 if the model has no such clip or its length is
     *         unknown
     */
    public int clipTicks(int clip) {
        if (clip < 0 || clip >= this.armLengths.length) {
            return 0;
        }
        return (int) Math.ceil(this.armLengths[clip] * 20.0 - 1e-4);
    }

    /** @return the idle clip's length in seconds, 0 without idle */
    public float idleLength() {
        return this.idleLength;
    }
}
