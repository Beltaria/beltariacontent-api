package fr.beltaria.content.api.cem;

import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * The CEM models of BeltariaContent's pack, for the plugin that gives them a behaviour: it reads
 * the host, the variant and the clips here and never numbers anything itself.
 *
 * <p>Registered by BeltariaContent in Bukkit's ServicesManager while it is enabled. {@code
 * /content reload} replaces the whole snapshot at once, then fires {@link CemModelsChangedEvent}
 * on the main thread: hold a snapshot for one load, and load again on the event.
 */
public interface CemModels {

    /** @return the implementation BeltariaContent registered, or null when it is not enabled */
    static CemModels get() {
        RegisteredServiceProvider<CemModels> provider =
                Bukkit.getServicesManager().getRegistration(CemModels.class);
        return provider == null ? null : provider.getProvider();
    }

    /** @return every model by id, immutable; one consistent snapshot, safe from any thread */
    Map<String, CemModel> models();
}
